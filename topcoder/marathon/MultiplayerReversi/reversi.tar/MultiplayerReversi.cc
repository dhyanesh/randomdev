#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <set>
#include <vector>

#include "MultiplayerMinMax.h"
#define DBG

using namespace std;

typedef vector<string> VS;
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef long long ll;

vector<string> toks(string inp,string delim)   
{   
  char *ch = strdup(inp.c_str());   
  char *ptr = strtok(ch,delim.c_str());   
  vector<string> ret;   
  while (ptr != NULL){   
    ret.push_back(ptr);   
    ptr = strtok(NULL,delim.c_str());   
  }   
  free(ch);   
  return ret;   
}   

class ReversiState : public State {
 public:
  ReversiState(const VS &board, int player)
    : players_(0),
      player_(player),
      n_(board.size()),
      moves_(0),
      next_move_x_(0),
      next_move_y_(-1) {
    Clear();
    for (int i = 0; i < n_; ++i) {
      for (int j = 0; j < n_; ++j) {
        if (board[i][j] != '.') {
          SetPlayer(i, j, board[i][j] - '0');
          players_ = max(players_, board[i][j] - '0');
        }
      }
    }
  }

  ReversiState(const ReversiState &copy)
    : player_(copy.player_),
      players_(copy.players_),
      n_(copy.n_),
      moves_(0),
      next_move_x_(0),
      next_move_y_(-1) {
    memcpy(board_, copy.board_, sizeof(board_));
  }

  virtual ~ReversiState() { }

  virtual State *NextState(vector<int> *move) {
    while (true) {
      ++next_move_y_;
      if (next_move_y_ == n_) {
        ++next_move_x_;
        next_move_y_ = 0;
      }
      if (next_move_x_ == n_) {
        if (moves_ == 0) {
          // If we have no moves to make, we "pass" the current turn i.e.
          // passing the current state as the next state.
          ReversiState *next_state = new ReversiState(*this);
          next_state->player_ = next_state->player_ % players_ + 1;
          ++moves_;
          return next_state;
        }
        return NULL;
      }
      ReversiState *next_state = new ReversiState(*this);
      if (next_state->DoMove(next_move_x_, next_move_y_)) {
        (*move)[0] = next_move_x_;
        (*move)[1] = next_move_y_;
        ++moves_;
        next_state->player_ = next_state->player_ % players_ + 1;
        return next_state;
      } else {
        delete next_state;
      }
    }
    return NULL;
  }

  virtual void GetScore(Result *result) const {
    for (int i = 0; i < n_; ++i) {
      for (int j = 0; j < n_; ++j) {
        int player = GetPlayer(i, j);
        if (player != 0) {
          // MultiplayerMinMax uses 0-based players
          result->AddScore(player - 1, 1.0);
        }
      }
    }
  }

  virtual int GetPlayer() const {
    // MultiplayerMinMax uses 0-based players
    return player_ - 1;
  }
  
  void PrintDebugString() const {
    for (int i = 0; i < 12; ++i) {
      fprintf(stderr, "%08x\n", board_[i]);
    }
  }

 private:
  void Clear() {
    memset(board_, 0, sizeof(board_));
  }

  void SetColumn(int col, int player, ll *board_row) {
    *board_row |= (long long)player << 4 * col;
  }

  void SetPlayer(int row, int col, int player) {
    SetColumn(col, player, &board_[row]);
  }

  int GetColumn(ll board_row, int col) const {
    return (board_row & (0xFLL << 4 * col)) >> 4 * col;
  }

  int GetPlayer(int row, int col) const {
    return GetColumn(board_[row], col);
  }

  bool DoMove(int x, int y) {
    if (GetPlayer(x, y) != 0) return false;
    int dx[] = { 1, 1, 1, -1, -1, -1, 0 , 0 };
    int dy[] = { 1, -1, 0, 1, -1 , 0, 1, -1};

    for (int i = 0; i < 8; ++i) {
      int nx = x + dx[i];
      int ny = y + dy[i];
      int c = 0;
      while (inbound(nx, ny)) {
        int npl = GetPlayer(nx, ny);
        if (npl == 0) {
          break;
        }
        if (npl == player_) {
          if (c > 0) {
            SetPlayer(x, y, player_);
            return true;
          } else {
            break;
          }
        }
        SetPlayer(nx, ny, player_);
        nx += dx[i];
        ny += dy[i];
        c++;
      }
    }

    return false;
  }

  bool inbound(int x, int y) {
    return x >= 0 && x < n_ && y >= 0 && y < n_;
  }

  int player_;
  int players_;
  // 4 bits represent one cell
  ll board_[12];
  int n_;

  int moves_;
  int next_move_x_;
  int next_move_y_;

  int undo_move_x_;
  int undo_move_y_;
  ll undo_values_;
};

class MultiplayerReversi {
  public:
    vector<int> getNextMove(vector<string> board) {
      int players = 0;
      for (int i = 0; i < board.size(); ++i) {
        for (int j = 0; j < board.size(); ++j) {
          if (board[i][j] != '.') {
            players = max(players, board[i][j] - '0');
          }
        }
      }
      MultiplayerMinMax min_max(players, 4);
      ReversiState initial_state(board, 1);
      Result result(players);
      VI ret;
      min_max.FindBestMove(&initial_state, &ret, &result);
      swap(ret[0], ret[1]);
      return ret;
    }
  private:

};

int main(void) {
  MultiplayerReversi obj;
  char buff[500];
  vector<string> board;
  vector<int> move;

  while(true) {
    board.clear();
    int N;
    if (scanf("%d", &N) != 1) {
      break;
    }
    getchar();
    fgets(buff, sizeof(buff), stdin);
    vector<string> board = toks(buff, " \n");
#ifdef DBG
    for (int i = 0; i < board.size(); ++i) {
      fprintf(stderr, "%s\n", board[i].c_str());
    }
#endif
    move = obj.getNextMove(board);
#ifdef DBG
    fprintf(stderr, "%d %d\n", move[0], move[1]);
#endif
    printf("%d %d\n", move[0], move[1]);
    fflush(stdout);
  }
  return 0;
}
